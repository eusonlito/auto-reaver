char cmd_pixie[4000];
char cmd_pixie_aux[4000];

char pixie_buf_aux[4000];
char pixie_buf_aux2[4000];

//fixed size
char pixie_pke[1000];					/* save pke */
char pixie_pkr[1000];					/* save pkr */
char pixie_enonce[100];					/* save e-nonce */
char pixie_rnonce[100];					/* save r-nonce */
char pixie_authkey[100];				/* save AuthKey */
char pixie_ehash1[100];					/* save e-hash1 */
char pixie_ehash2[100];					/* save e-hash2 */
	
//int op_pixie=0;

